package main;

import javafx.application.Application;
import view.StartGUI;

public class StudentManagementGUIFXML3Test
{
  public static void main(String[] args)
  {
    Application.launch(StartGUI.class);
  }
}
